package InterestCalc;

import static org.junit.Assert.*;

import org.junit.Test;

public class RDAccountTest {

	@Test
	public void testGetInterestRate() {
		assertTrue(true);
	}

	@Test
	public void testSetInterestRate() {
		assertTrue(true);
	}

	@Test
	public void testGetAmount() {
		assertTrue(true);
	}

	@Test
	public void testSetAmount() {
		assertTrue(true);
	}

	@Test
	public void testGetNoOfMonth() {
		assertTrue(true);
	}

	@Test
	public void testSetNoOfMonth() {
		assertTrue(true);
	}

	@Test
	public void testGetMonthlyAmount() {
		assertTrue(true);
	}

	@Test
	public void testSetMonthlyAmount() {
		assertTrue(true);
	}

	@Test
	public void testGetAgeOfACHolder() {
		assertTrue(true);
	}

	@Test
	public void testSetAgeOfACHolder() {
		assertTrue(true);
	}

}
