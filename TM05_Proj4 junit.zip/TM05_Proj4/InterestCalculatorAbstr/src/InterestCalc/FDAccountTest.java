package InterestCalc;

import static org.junit.Assert.*;

import org.junit.Test;

public class FDAccountTest {

	@Test
	public void testGetNoOfDays() {
		assertTrue(true);
	}

	@Test
	public void testSetNoOfDays() {
		assertTrue(true);
	}

	@Test
	public void testGetAgeOfACHolder() {
		assertTrue(true);
	}

	@Test
	public void testSetAgeOfACHolder() {
		assertTrue(true);
	}

	@Test
	public void testGetInterestRate() {
		assertTrue(true);
	}

	@Test
	public void testSetInterestRate() {
		assertTrue(true);
	}

	@Test
	public void testGetAmount() {
		assertTrue(true);
	}

	@Test
	public void testSetAmount() {
		assertTrue(true);
	}

}
