package main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import InterestCalc.*;

@RunWith(Suite.class)
@SuiteClasses({ InterestCalculatorTest.class, FDAccountTest.class, RDAccountTest.class, SBAccountTest.class  })
public class AllTests {

	
}