package main;

import static org.junit.Assert.*;

import org.junit.Test;

public class InterestCalculatorTest {

	@Test
	public void testMain() {
		assertTrue(true);
	}

}
