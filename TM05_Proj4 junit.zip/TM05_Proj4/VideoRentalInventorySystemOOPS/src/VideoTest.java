import static org.junit.Assert.*;

import org.junit.Test;

public class VideoTest {

	@Test
	public void testVideo() {
		assertTrue(true);
	}

	@Test
	public void testVideoString() {
		assertTrue(true);

	}

	@Test
	public void testGetName() {
		assertTrue(true);

	}

	@Test
	public void testDoCheckout() {
		assertTrue(true);

	}

	@Test
	public void testDoReturn() {
		assertTrue(true);
	}

	@Test
	public void testReceiveRating() {
		assertTrue(true);

	}

	@Test
	public void testGetRating() {
		assertTrue(true);

	}

	@Test
	public void testGetCheckout() {
		assertTrue(true);
	}

}
