import static org.junit.Assert.*;

import org.junit.Test;

public class VideoStoreTest {

	@Test
	public void testVideoStore() {
		assertTrue(true);

	}

	@Test
	public void testAddVideo() {
		assertTrue(true);
	}

	@Test
	public void testDoCheckout() {
		assertTrue(true);
	}

	@Test
	public void testDoReturn() {
		assertTrue(true);
	}

	@Test
	public void testReceiveRating() {
		assertTrue(true);
	}

	@Test
	public void testListInventory() {
		assertTrue(true);
	}

}
