class p1
{
	public static void main(String a[])
	{
		System.out.println(a[0] +" Technologies "+ a[1]);
	}
}