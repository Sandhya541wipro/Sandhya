class p2
{
	public static void main(String a[])
	{
		System.out.println("Welcome "+ a[0]);
	}
}