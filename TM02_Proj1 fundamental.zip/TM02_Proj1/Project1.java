class Project1
{
	public static void main(String ar[])
	{
		
		int flag=0,sal=0;
		int empno[]={1001,1002,1003,1004,1005,1006,1007};
		String empname[]={"Ashish","Shushma","Rahul","Chahat","Ranjan","Suman","Tanmay"};
		String joindate[]={"01/04/2009","23/08/2012","12/11/2008","29/01/2013","16/07/2005","01/01/2000","12/06/2016"};
		String desg[]={"Engineer","Consultant","Clerk","Receptionist","Manager","Engineer","Consultant"};
		String dept[]={"R&D","PM","Acct","Front Desk","Engg","Manufacturing","PM"};
		int basic[]={20000,30000,10000,12000,50000,23000,29000};
		int hra[]={8000,12000,8000,6000,20000,9000,12000};
		int it[]={3000,9000,1000,2000,20000,4400,10000};
		int da[]={20000,32000,12000,15000,40000,20000,32000};
		
		int empnum=Integer.parseInt(ar[0]);
		for(int i=0;i<=6;i++)
		{
			if(empnum==empno[i])
			{
				flag++;
				sal=(basic[i]+hra[i]+da[i])-it[i];
				System.out.println("Emp no"+"\t"+"    Emp Name"+"\t"+"  Department"+"\t"+"  Desgination"+"\t"+"        Salary");
				System.out.println(empno[i]+"\t"+"\t"+empname[i]+"\t"+"\t"+dept[i]+"\t"+"\t"+desg[i]+"\t"+"\t"+sal);
				
			}
		}
		if(flag==0)
			System.out.println("There is no employee with empid :"+ar[0]);
	}
}