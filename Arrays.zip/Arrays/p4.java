import java.util.*;
class p4
{
    public static void main(String args[])
    {
        int a[]={65,68,44,45,48,51};
        System.out.println("Ascii numbers");
        for(int i=0;i<6;i++)
        System.out.print(a[i]+"\t");
        System.out.println();
        System.out.println("Ascii Values");
        for(int i=0;i<6;i++)
        System.out.print((char)a[i]+"\t");
    }
}
